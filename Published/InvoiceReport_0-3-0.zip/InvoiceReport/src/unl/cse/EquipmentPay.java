package unl.cse;

/**
 * <b>EquipmentPay</b> is used to model data for equipment invoiced
 * 
 * @author Alexis Kennedy
 * @author Jacob Charles
 * @version 0.2.0
 */
public class EquipmentPay {
	private String code;
	private int units;
	private double total;
	private double taxed;
	private double cost;
	private String info;
	
	public EquipmentPay() {}

	/**
	 * 
	 * @param code - Identification for the invoice (String)
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * 
	 * @param units - Number of equipment purchased (double)
	 */
	public void setUnits(int units) {
		this.units = units;
	}
	
	/**
	 * 
	 * @param total - Total cost of this product invoice (double)
	 */
	public void setTotal(double total) {
		this.total = total;
	}
	
	/**
	 * 
	 * @param taxed - Amount taxed from the invoice (double)
	 */
	public void setTaxed(double taxed) {
		this.taxed = taxed;
	}
	
	/**
	 * 
	 * @param cost - Subtotal cost of the product invoice (double)
	 */
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	/**
	 * 
	 * @param info - Brief information about the product invoice (String)
	 */
	public void setInfo(String info) {
		this.info = info;
	}
	
	/**
	 * 
	 * @return - Returns a String
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * 
	 * @return - Returns a integer
	 */
	public int getUnits() {
		return this.units;
	}
	
	/**
	 * 
	 * @return - Returns a double
	 */
	public double getTotal() {
		return this.total;
	}
	
	/**
	 * 
	 * @return - Returns a double
	 */
	public double getTaxed() {
		return this.taxed;
	}
	
	/**
	 * 
	 * @return - Returns a double
	 */
	public double getCost() {
		return this.cost;
	}
	
	/**
	 * 
	 * @return - Returns a String
	 */
	public String getInfo() {
		return this.info;
	}
}