package unl.cse;

/**
 * <b>LicensePay</b> is used to model data for license invoiced
 * 
 * @author Alexis Kennedy
 * @author Jacob Charles
 * @version 0.2.0
 */
public class LicensePay {
	
	private String code;
	private String startDate;
	private String endDate;
	private int days;
	private double total;
	private double taxed;
	private double cost;
	private double fee;
	private String info;
	
	public LicensePay() {}
	
	/**
	 * 
	 * @param code - Identification for the invoice (String)
	 */
	public void setCode(String code) {
		this.code = code;
	}
	
	/**
	 * 
	 * @param startDate - Date the License starts in YYYY-MM-DD (String)
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	
	/**
	 * 
	 * @param endDate - Date the License ends in YYYY-MM-DD (String)
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	/**
	 * 
	 * @param total - Total cost of this product invoice (double)
	 */
	public void setTotal(double total) {
		this.total = total;
	}
	
	/**
	 * 
	 * @param days - Number of days the license last
	 */
	public void setDays(int days) {
		this.days = days;
	}
	
	/**
	 * 
	 * @param cost - Subtotal cost of the product invoice (double)
	 */
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	/**
	 * 
	 * @param taxed - Amount taxed from the invoice (double)
	 */
	public void setTaxed(double taxed) {
		this.taxed = taxed;
	}
	
	/**
	 * 
	 * @param fee - total fee of the license (double)
	 */
	public void setFee(double fee) {
		this.fee = fee;
	}
	
	/**
	 * 
	 * @param info - Brief information about the product invoice (String)
	 */
	public void setInfo(String info) {
		this.info = info;
	}
	
	/**
	 * 
	 * @return - Returns a String
	 */
	public String getCode() {
		return this.code;
	}
	
	/**
	 * 
	 * @return - Returns a String
	 */
	public String getStartDate() {
		return this.startDate;
	}
	
	/**
	 * 
	 * @return - Returns a String
	 */
	public String getEndDate() {
		return this.endDate;
	}
	
	/**
	 * 
	 * @return - Returns a double
	 */
	public double getTotal() {
		return this.total;
	}
	
	/**
	 * 
	 * @return - Returns a integer
	 */
	public int getDays() {
		return this.days;
	}
	
	/**
	 * 
	 * @return - Returns a double
	 */
	public double getCost() {
		return this.cost;
	}
	
	/**
	 * 
	 * @return - Returns a double
	 */
	public double getTaxed() {
		return this.taxed;
	}
	
	/**
	 * 
	 * @return - Returns a double
	 */
	public double getFee() {
		return this.fee;
	}
	
	/**
	 * 
	 * @return - Returns a String
	 */
	public String getInfo() {
		return this.info;
	}
}