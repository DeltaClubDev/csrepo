package unl.cse;

/**
 * <b>ConsultPay</b> is used to model data for consultations invoiced
 * 
 * @author Alexis Kennedy
 * @author Jacob Charles
 * @version 0.2.0
 */
public class ConsultPay {
	private String code;
	private double hours;
	private double total;
	private double taxed;
	private double cost;
	private String info;
	
	public ConsultPay() {}

	/**
	 * 
	 * @param code - Identification for the invoice (String)
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * 
	 * @param hours - Number of hours the consultation was (double)
	 */
	public void setHours(double hours) {
		this.hours = hours;
	}
	
	/**
	 * 
	 * @param total - Total cost of this product invoice (double)
	 */
	public void setTotal(double total) {
		this.total = total;
	}
	
	/**
	 * 
	 * @param cost - Subtotal cost of the product invoice (double)
	 */
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	/**
	 * 
	 * @param taxed - Amount taxed from the invoice (double)
	 */
	public void setTaxed(double taxed) {
		this.taxed = taxed;
	}
	
	/**
	 * 
	 * @param info - Brief information about the product invoice (String)
	 */
	public void setInfo(String info) {
		this.info = info;
	}
	
	/**
	 * 
	 * @return - Returns a String
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * 
	 * @return - Returns a double
	 */
	public double getHours() {
		return this.hours;
	}
	
	/**
	 * 
	 * @return - Returns a double
	 */
	public double getTotal() {
		return this.total;
	}
	
	/**
	 * 
	 * @return - Returns a double
	 */
	public double getCost() {
		return this.cost;
	}
	
	/**
	 * 
	 * @return - Returns a double
	 */
	public double getTaxed() {
		return this.taxed;
	}
	
	/**
	 * 
	 * @return - Returns a String
	 */
	public String getInfo() {
		return this.info;
	}
}