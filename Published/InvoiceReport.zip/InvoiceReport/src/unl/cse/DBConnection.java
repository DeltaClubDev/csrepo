package unl.cse;

/**
 * DataBase connection info
 * @author Jacob Charles
 * @version 0.5.0
 */
public class DBConnection {
	public static final String DB_URL = "jdbc:mysql://cse.unl.edu/jcharles";
	public static final String DB_USERNAME = "jcharles";
	public static final String DB_PASSWORD = "VUM#=p";
}
